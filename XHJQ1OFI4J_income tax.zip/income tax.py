salary=(input())
#Discounted salary
salary=int(salary)-50000

taxslabtwo=((5/100)*salary)
taxslabthree=((10/100)*salary)
taxslabfour=((15/100)*salary)
taxslabfive=((20/100)*salary)
taxslabsix=((25/100)*salary)
taxslabseven=((30/100)*salary)
#if salary is less than 250000
if salary<=250000:
    print("Nil")
#if salary is between 2,50,000 and 5,00,000
if (salary>250000) and (salary<=500000):
    print(taxslabtwo)
#if salary is between 5,00,000 and 7,50,000
if (salary>500000) and (salary<=750000):
    print(taxslabthree-( ((5/100)*250000) + ((10/100)*250000) ))
#if salary is between 7,50,000 and 10,00,000
if (salary>750000) and (salary<=1000000):
    print(taxslabfour-(((5/100)*250000)+((10/100)*250000)+((15/100)*250000)))
#if salary is between 10,00,000 and 12,50,000
if (salary>1000000) and (salary<=1250000):
    print(taxslabfive-(((5/100)*250000)+((10/100)*250000)+((15/100)*250000)+((20/100)*250000)))
#if salary is between 12,50,000 and 15,00,000
if (salary>1250000)and (salary<=1500000):
    print(taxslabsix-(((5/100)*250000)+((10/100)*250000)+((15/100)*250000)+((20/100)*250000)+((25/100)*250000)))
#if salary is more than 15,00,000
if salary>1500000:
    print(taxslabseven-(((5/100)*250000)+ ((10/100)*250000) + ((15/100)*250000)+((20/100)*250000)+((25/100)*250000)+((30/100)*250000)))